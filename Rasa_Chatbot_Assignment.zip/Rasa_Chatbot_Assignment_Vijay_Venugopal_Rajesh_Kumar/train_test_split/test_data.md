## intent:default
- :D
- haha

## intent:affirm
- ofcourse
- yes pleae
- ok...
- it is ok
- Yes.
- PLEASE
- yes of course
- Yup
- uh-huh
- ok, Sara
- I'm sure I will!
- great!
- yez
- yes it is
- hell yeah
- Okay
- Yepp
- Okay!
- yes that's what i want
- ya thats cool
- go for it
- I'm using it
- I do
- yess
- i am!
- okay..
- accept
- yeah
- jezz
- ofcoure i do
- going super well
- cool!
- yes, cool
- yep, will do thank you
- Yes please!
- thats fine
- yeah do that
- yesyesyes
- cool
- yres
- i will!
- yes that's great
- yes give me information
- SURE
- that is cool
- that ok

## intent:goodbye
- Bye bye
- See you
- stop
- Meet again

## intent:greet
- Namaste
- Are you there
- hey there
- you are driving me crazy
- hey yo
- What's up
- Hello
- greet
- sorry to bother you

## intent:low
- [299](price:low)

## intent:mid
- [499](price:mid)

## intent:high
- [999](price:high)

## intent:email_affirm
- ok, send them to [vijay#yahoo.com](email)
- yes please, send it to [vvijay83@gmail.com](email)
- please send it
- sure here is my email id [vvijay@123.com](email)
- okay
- here is my email [google@gmail.com](email)
- ok
- yes please send it to [vvijay83@gmail.com](email)
- sounds really good
- why not, send it through

## intent:email_deny
- no. thanks
- sorry
- no sorry
- no need

## intent:emailID
- [asfbc@adsf.com.au](email)
- [vijay#google](email)
- [rajas#yahoo](email)
- [jddk.2jmd@kdl.co.in](email)
- [invalidemail.com](email)

## intent:restaurant_search
- find me some restaurant
- around [Kalyan-Dombivli](location)
- looking for [pastry](cuisine)
- I'm really hungry
- can you find a retaurant in [Mangalore](location) in a [good ambience](price:high) price range with [North Indian](cuisine) food for two people
- Oh, sorry, in [Chennai](location)
- [greek](cuisine)
- at [Aurangabad](location)
- [turkish](cuisine)
- i am looking for [high range](price:high)
- in [Shahjahanpur](location)
- [vaniyambadi](location)
- [irish](cuisine)
- [canadian](cuisine)
- [mumbai](location:Mumbai)
- anywhere in [Coimbatore](location)
- i am looking for [south indian](cuisine) restaurant in [jaipur](location)
- Please find me some [cheap](price:low) [north indian](cuisine) restaurants near [mangalore](location)
- around [Bangalore](location)
- restaurant
- at [Coimbatore](location))
- [pollachi](location)
- [Delhi](location)
- [kolkata](location)
- [medium price range](price:mid)
- please find me [chinese](cuisine) restaurant in [delhi](location)
- how about [swedish](cuisine)?
- Can you suggest some good restaurants in [kolkata](location)
- around [Varanasi](location)
- [400 - 500](price:mid)
- around [Lucknow](location)
- in the city [Udaipur](location)
- suggest me some [high](price) class restaurant near [vadalur](location)
- [shimla](location)
- [kolkatas](location)
- in [Satara](location)
- [American](cuisine)
- show me restaurants
- hey, i am hungry. can you tell me where are some [moderate](price:mid) priced [north indian](cuisine) restaurant
- [modern](price:high)
- [high end](price:high)
- [delhi](location)
- [310](price:mid)
- i will try [spanish](cuisine)
- around [Agra](location)
- show me [chines](cuisine:Chinese) restaurants in the [New Delhi](location:Delhi)
- I'll prefer [chines](cuisine:Chinese)
- can you suggest some [cheap](price:low) [spanish](cuisine) restaurant around [kochi](location)
- find me some [italian](cuisine) restaurant around [hyderabad](location)
- [limited](price:low)
- can i find something like [cookies](cuisine)
- in the city [Davanagere](location)
- I am looking for [South Indian](cuisine) food
- in [Kurnool](location)
- are there [german](cuisine) cuisines available?
- [112](price:low)
- in [Sambalpur](location)
- i am really hungry and looking out for some [korean](cuisine) restaurant near [veppur](location)
- [300-700](price:mid)
- may i ask you about some [premium](price:high) [french](cuisine) restaurants around [salem](location)
- suggest me some restaurant
- [krishnagiri](location)
- [599](price:mid)
- [500](price:mid)
- help me to find some restaurants near [kolkata](location)
- in [Mumbai](location)
- can you find a retaurant in [Warangal](location) in a [moderate](price:mid) price range with [American](cuisine) food for four people
- can you help me find some [chinese](cuisine:Chinese) restaurant

## synonym:Ahmedabad
- Amdavad
- Ahmedbad

## synonym:American
- Western
- Amrican

## synonym:Bangalore
- Bengaluru
- bengaluru
- Bangaluru
- bangalore
- bengalore

## synonym:Chennai
- chennai
- chenai
- Madras
- Madrasapattinam
- Chenai

## synonym:Chinese
- chines
- chinese
- Chines
- noodles
- sichuan
- momos
- dumplings
- sino

## synonym:Delhi
- New Delhi
- Dilli
- Dilhi
- Navi Delhi
- deli
- delli
- dhelli

## synonym:Hyderabad
- Hyderbad
- Hydrabad
- hiderbad
- hydrabad

## synonym:Italian
- Pasta
- Cheese
- Pizza
- Spaghetti
- Margarita

## synonym:Kolkata
- Calcutta
- Kalkatta
- Kalkata
- Colcatta
- Colcutta
- kolkatas
- culcuta
- calcata
- kalkata

## synonym:Mexican
- Tacos
- Mexcan
- Mxican

## synonym:Mumbai
- mumbai
- Bombay
- Navi Mumbai

## synonym:North Indian
- Nort Indian
- Norh Indian
- Thali
- Roti
- Chapathi

## synonym:Pune
- Poona
- Poone
- puune

## synonym:South Indian
- Soth Indian
- Suth Indian
- Biriyani
- Briyani
- Dosa
- Idly
- Idli

## synonym:high
- 701
- 799
- 999
- good ambience
- high range
- more than 700
- greater than 700
- expensive
- >700
- premium
- luxury
- posh
- ambience
- rich
- buffet
- high price
- roof top
- high end
- 900
- 1000
- above 700
- top class
- VIP
- modern

## synonym:low
- 112
- 299
- 149
- cheap
- Lesser than Rs. 300
- less than 300
- <300
- 0 to 300
- 0 - 300
- low range
- cheaper
- budget
- limited
- inexpensive
- low price
- budget price
- 200-300
- 100-300
- 200 - 300
- 100 - 300
- 100
- 200
- 300

## synonym:mid
- 310
- 499
- 599
- moderate
- mid range
- 300 to 700
- 300 - 700
- average price
- 300-700
- medium price
- average priced
- middle range
- 350
- 400
- 500
- 600
- 700
- normal
- usual
- affordable
- decent
- average price range
- medium
- medium price range
- 400-500
- 400 - 500
- 500-600
- 500 - 600
- 600-700
- 600 - 700

## regex:(price:high)
- \b(70[1-9]|7[1-9][0-9]|[89][0-9]{2}|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-8][0-9]{4}|9[0-8][0-9]{3}|99[0-8][0-9]{2}|999[0-8][0-9]|9999[0-9]|[1-8][0-9]{5}|9[0-8][0-9]{4}|99[0-8][0-9]{3}|999[0-8][0-9]{2}|9999[0-8][0-9]|99999[0-9]|[1-8][0-9]{6}|9[0-8][0-9]{5}|99[0-8][0-9]{4}|999[0-8][0-9]{3}|9999[0-8][0-9]{2}|99999[0-8][0-9]|999999[0-9]|[1-8][0-9]{7}|9[0-8][0-9]{6}|99[0-8][0-9]{5}|999[0-8][0-9]{4}|9999[0-8][0-9]{3}|99999[0-8][0-9]{2}|999999[0-8][0-9]|9999999[0-9]|[1-8][0-9]{8}|9[0-8][0-9]{7}|99[0-8][0-9]{6}|999[0-8][0-9]{5}|9999[0-8][0-9]{4}|99999[0-8][0-9]{3}|999999[0-8][0-9]{2}|9999999[0-8][0-9]|99999999[0-9]|1000000000)\b

## regex:(price:low)
- \b([0-9]|[1-8][0-9]|9[0-9]|[12][0-9]{2}|300)\b

## regex:(price:mid)
- \b(30[1-9]|3[1-9][0-9]|[4-6][0-9]{2}|700)\b

## regex:default
- \b^[_a-zA-Z0-9-]+\b

## regex:email
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*#[a-z]+(\.[a-z]+)*(\.[a-z]{2,3})$\b
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*#[a-z]+(\.[a-z]+)*\b
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*#[a-z]+\b
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*$[a-z]+(\.[a-z]+)*(\.[a-z]{2,3})$\b
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*$[a-z]+(\.[a-z]+)*\b
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*$[a-z]+\b
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*%[a-z]+(\.[a-z]+)*(\.[a-z]{2,3})$\b
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*%[a-z]+(\.[a-z]+)*\b
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*%[a-z]+\b
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-z]+(\.[a-z]+)*(\.[a-z]{2,3})$\b
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-z]+(\.[a-z]+)*\b
- \b^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-z]+\b
- \b^[a-z]+(\.[a-z]+)
- \b^[a-z]+(\.[a-z]+)*(\.[a-z]{2,3})$\b

## regex:greet
- hello [^\s]*
- hey[^\s]*
- hi [^\s]*

## regex:location
- \b^[a-zA-Z]+Bhavi$\b
- \b^[a-zA-Z]+Garh$\b
- \b^[a-zA-Z]+Gud$\b
- \b^[a-zA-Z]+Halli$\b
- \b^[a-zA-Z]+Kaadu$\b
- \b^[a-zA-Z]+Keri$\b
- \b^[a-zA-Z]+Kote$\b
- \b^[a-zA-Z]+Oor$\b
- \b^[a-zA-Z]+Ooru$\b
- \b^[a-zA-Z]+Pete$\b
- \b^[a-zA-Z]+Pur$\b
- \b^[a-zA-Z]+Pura$\b
- \b^[a-zA-Z]+assa$\b
- \b^[a-zA-Z]+bari$\b
- \b^[a-zA-Z]+chhara$\b
- \b^[a-zA-Z]+halli$\b
- \b^[a-zA-Z]+kal$\b
- \b^[a-zA-Z]+kudi$\b
- \b^[a-zA-Z]+mura$\b
- \b^[a-zA-Z]+ore$\b
- \b^[a-zA-Z]+patti$\b
- \b^[a-zA-Z]+puram$\b
- \b^[a-zA-Z]+uru$\b

## lookup:location
  data/locations.txt
